import {json} from './_auth.mjs';
export default async ()=>json({url:process.env.SUPABASE_URL||'',anonKey:process.env.SUPABASE_ANON_KEY||'',configured:!!(process.env.SUPABASE_URL&&process.env.SUPABASE_ANON_KEY)});
