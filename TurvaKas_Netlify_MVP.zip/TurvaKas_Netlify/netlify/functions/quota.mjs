import {getStore} from '@netlify/blobs';
import {authenticate,json} from './_auth.mjs';
const MAX_BYTES=2*1024*1024;
export default async request=>{
  const user=await authenticate(request); if(!user) return json({error:'Logi sisse.'},401);
  const store=getStore('turvakas-usage');
  const week=Math.floor(Date.now()/604800000);
  const key=`${user.id}/${week}`;
  const method=request.method;
  const usage=(await store.get(key,{type:'json'}))||{count:0};
  if(method==='GET')return json({used:usage.count,limit:2,week});
  if(method!=='POST')return json({error:'Meetod keelatud'},405);
  const body=await request.json().catch(()=>({}));
  if(typeof body.bytes!=='number'||body.bytes<1||body.bytes>MAX_BYTES)return json({error:'Fail peab olema kuni 2 MB.'},400);
  // Demonstration quota only. Netlify Blobs read/write is not atomic under concurrent requests.
  if(usage.count>=2)return json({error:'Tasuta paketi nädala limiit täis.'},429);
  await store.setJSON(key,{count:usage.count+1});
  return json({used:usage.count+1,limit:2});
};
